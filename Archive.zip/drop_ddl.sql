begin;

drop table if exists cats.cats;
drop schema if exists cats;

commit;
